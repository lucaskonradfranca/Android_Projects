var searchData=
[
  ['id_5ffield',['ID_FIELD',['../classmodels_1_1_room.html#a5f17d702615d2f9c79a6092b83807e61',1,'models::Room']]],
  ['isstatus',['isStatus',['../classutil_1_1_retorno_rest.html#acbe67b937dbc0bb62e2cdc4e05b2cf77',1,'util::RetornoRest']]]
];
