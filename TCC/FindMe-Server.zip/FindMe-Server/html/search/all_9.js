var searchData=
[
  ['name_5ffield',['NAME_FIELD',['../classmodels_1_1_room.html#a936f0e12647ef297be3aabf74c0aafdd',1,'models::Room']]],
  ['network_5fname_5ffield',['NETWORK_NAME_FIELD',['../classmodels_1_1_location_data.html#a109059543f68e5bfc740397db5363d35',1,'models::LocationData']]]
];
