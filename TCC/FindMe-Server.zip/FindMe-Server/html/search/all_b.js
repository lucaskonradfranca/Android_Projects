var searchData=
[
  ['realizarlogin',['realizarLogin',['../classresources_1_1_login_resource.html#a2983ce3e2d7be8670effd487aaeb8907',1,'resources::LoginResource']]],
  ['resources',['resources',['../namespaceresources.html',1,'']]],
  ['retornorest',['RetornoRest',['../classutil_1_1_retorno_rest.html',1,'util']]],
  ['retornorest_2ejava',['RetornoRest.java',['../_retorno_rest_8java.html',1,'']]],
  ['room',['Room',['../classmodels_1_1_room.html',1,'models']]],
  ['room',['Room',['../classmodels_1_1_room.html#ab4ddaf5d544a834f00f1ded3de72ec82',1,'models::Room']]],
  ['room_2ejava',['Room.java',['../_room_8java.html',1,'']]],
  ['room_5ffield',['ROOM_FIELD',['../classmodels_1_1_location_data.html#ae9b06aa3fccb79f9045b7ade87f35339',1,'models::LocationData']]],
  ['roomservice',['RoomService',['../classservices_1_1_room_service.html#a6295cfa7e099005f2f90b9dd5fef09c6',1,'services::RoomService']]],
  ['roomservice',['RoomService',['../classservices_1_1_room_service.html',1,'services']]],
  ['roomservice_2ejava',['RoomService.java',['../_room_service_8java.html',1,'']]]
];
