var searchData=
[
  ['updateuser',['UpdateUser',['../classresources_1_1_usuario_resource.html#ac69671fef719260645b8b70a656f5ebf',1,'resources::UsuarioResource']]],
  ['url',['url',['../classutil_1_1_conexao_b_d.html#ab7d878c6f620296147b61ef999cbd1fa',1,'util::ConexaoBD']]],
  ['username',['username',['../classutil_1_1_conexao_b_d.html#aa1b2564b043968bb9227cdc527ee8c09',1,'util::ConexaoBD']]],
  ['usuario',['Usuario',['../classmodels_1_1_usuario.html#a85478da86a8b00726030926253e5dddf',1,'models.Usuario.Usuario()'],['../classmodels_1_1_usuario.html#a6bef05b8d722e33049400575ec79a2c0',1,'models.Usuario.Usuario(String matricula, String nome, String email, String senha, String data_nascimento, String first_login, int nivel_privacidade)']]],
  ['usuario',['Usuario',['../classmodels_1_1_usuario.html',1,'models']]],
  ['usuario_2ejava',['Usuario.java',['../_usuario_8java.html',1,'']]],
  ['usuarioresource',['UsuarioResource',['../classresources_1_1_usuario_resource.html',1,'resources']]],
  ['usuarioresource_2ejava',['UsuarioResource.java',['../_usuario_resource_8java.html',1,'']]],
  ['util',['util',['../namespaceutil.html',1,'']]],
  ['uuid_5ffield',['UUID_FIELD',['../classmodels_1_1_location_data.html#a52f2f9897cc3cd350f80e122d81a96a0',1,'models::LocationData']]]
];
