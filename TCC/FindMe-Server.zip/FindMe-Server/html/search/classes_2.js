var searchData=
[
  ['databasemanager',['DatabaseManager',['../classutil_1_1_database_manager.html',1,'util']]]
];
