var searchData=
[
  ['locationdata',['LocationData',['../classmodels_1_1_location_data.html',1,'models']]],
  ['locationservice',['LocationService',['../classservices_1_1_location_service.html',1,'services']]],
  ['loginresource',['LoginResource',['../classresources_1_1_login_resource.html',1,'resources']]]
];
