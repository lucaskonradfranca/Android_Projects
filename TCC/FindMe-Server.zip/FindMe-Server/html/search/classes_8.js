var searchData=
[
  ['usuario',['Usuario',['../classmodels_1_1_usuario.html',1,'models']]],
  ['usuarioresource',['UsuarioResource',['../classresources_1_1_usuario_resource.html',1,'resources']]]
];
