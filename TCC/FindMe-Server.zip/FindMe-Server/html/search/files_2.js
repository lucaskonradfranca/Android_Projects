var searchData=
[
  ['databasemanager_2ejava',['DatabaseManager.java',['../_database_manager_8java.html',1,'']]]
];
