var searchData=
[
  ['abstractservice',['AbstractService',['../classservices_1_1_abstract_service.html#ac8cb890fb55df24ab644b365b40f7d41',1,'services::AbstractService']]],
  ['addaccesspoint',['addAccessPoint',['../classmodels_1_1_prediction_request.html#a724a6d6a0a606874ea8eec3c1fe36b94',1,'models::PredictionRequest']]],
  ['atualizar',['atualizar',['../classmodels_1_1_usuario.html#a8abbb5ba55e9d96c8a0e4e94c3ad2fcd',1,'models::Usuario']]]
];
