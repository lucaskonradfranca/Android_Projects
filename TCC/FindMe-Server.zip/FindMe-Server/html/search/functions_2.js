var searchData=
[
  ['disconnect',['disconnect',['../classutil_1_1_conexao_b_d.html#a65025eb4e719844edf4df51f3b71936b',1,'util::ConexaoBD']]]
];
