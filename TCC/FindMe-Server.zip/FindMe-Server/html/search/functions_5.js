var searchData=
[
  ['isstatus',['isStatus',['../classutil_1_1_retorno_rest.html#acbe67b937dbc0bb62e2cdc4e05b2cf77',1,'util::RetornoRest']]]
];
