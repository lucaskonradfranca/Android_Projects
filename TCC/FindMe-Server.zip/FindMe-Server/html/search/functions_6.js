var searchData=
[
  ['locationdata',['LocationData',['../classmodels_1_1_location_data.html#a98aee0c6ad272a024c3c81ccc983afef',1,'models::LocationData']]],
  ['locationservice',['LocationService',['../classservices_1_1_location_service.html#a85f8c2226b17fb1dbc11c707f4c8cd73',1,'services::LocationService']]],
  ['logar',['logar',['../classmodels_1_1_usuario.html#ae664bd8ed0ff461509cb852a163374d5',1,'models::Usuario']]]
];
