var searchData=
[
  ['predict',['predict',['../classservices_1_1_prediction_service.html#a831f8f8591c7c57ff3a2ad10e623449b',1,'services::PredictionService']]],
  ['predictionrequest',['PredictionRequest',['../classmodels_1_1_prediction_request.html#a8e4e26f2568bf572bd59ba0be84c18ef',1,'models::PredictionRequest']]]
];
