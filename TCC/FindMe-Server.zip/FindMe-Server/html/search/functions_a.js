var searchData=
[
  ['tostring',['toString',['../classmodels_1_1_usuario.html#ad239733508597a773a2440d39ae5d4ae',1,'models.Usuario.toString()'],['../classutil_1_1_retorno_rest.html#adbb490fc966e82d776850db4817ccfac',1,'util.RetornoRest.toString()']]],
  ['train',['train',['../classservices_1_1_prediction_service.html#a169d1fc31786286a2d922036a799b072',1,'services::PredictionService']]]
];
