var searchData=
[
  ['updateuser',['UpdateUser',['../classresources_1_1_usuario_resource.html#ac69671fef719260645b8b70a656f5ebf',1,'resources::UsuarioResource']]],
  ['usuario',['Usuario',['../classmodels_1_1_usuario.html#a85478da86a8b00726030926253e5dddf',1,'models.Usuario.Usuario()'],['../classmodels_1_1_usuario.html#a6bef05b8d722e33049400575ec79a2c0',1,'models.Usuario.Usuario(String matricula, String nome, String email, String senha, String data_nascimento, String first_login, int nivel_privacidade)']]]
];
