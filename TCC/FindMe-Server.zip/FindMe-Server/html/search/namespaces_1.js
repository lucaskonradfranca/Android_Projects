var searchData=
[
  ['resources',['resources',['../namespaceresources.html',1,'']]]
];
