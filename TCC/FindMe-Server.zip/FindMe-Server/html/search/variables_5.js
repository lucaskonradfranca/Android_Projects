var searchData=
[
  ['msgerro',['msgErro',['../classutil_1_1_conexao_b_d.html#a25750608a26562b734482aa2fc0caf06',1,'util::ConexaoBD']]]
];
