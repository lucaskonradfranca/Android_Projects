var searchData=
[
  ['room_5ffield',['ROOM_FIELD',['../classmodels_1_1_location_data.html#ae9b06aa3fccb79f9045b7ade87f35339',1,'models::LocationData']]]
];
