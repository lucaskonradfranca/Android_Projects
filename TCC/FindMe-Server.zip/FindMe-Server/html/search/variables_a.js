var searchData=
[
  ['url',['url',['../classutil_1_1_conexao_b_d.html#ab7d878c6f620296147b61ef999cbd1fa',1,'util::ConexaoBD']]],
  ['username',['username',['../classutil_1_1_conexao_b_d.html#aa1b2564b043968bb9227cdc527ee8c09',1,'util::ConexaoBD']]],
  ['uuid_5ffield',['UUID_FIELD',['../classmodels_1_1_location_data.html#a52f2f9897cc3cd350f80e122d81a96a0',1,'models::LocationData']]]
];
