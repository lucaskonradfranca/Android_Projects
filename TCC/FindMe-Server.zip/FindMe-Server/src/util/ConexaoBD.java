package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConexaoBD {

	public static String msgErro;
	public static String url;
	public static String driverName;
	public static String username;
	public static String password;
	
	public static java.sql.Connection getConexaoSQL(){

	    Connection connection = null; 
	    try { 
	        // Carrega o driver JDBC 
	        driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver"; //  JDBC driver
	        //url = "jdbc:sqlserver://Lucas\\SQLEXPRESS;databaseName=findme;";
	        url = "jdbc:sqlserver://FindMe;databaseName=findme;";
	        username = "findme";
	        //password = "findme";
	        password = "lucas.franca@123";
	        
	        Class.forName(driverName); // Create a conexao  com Banco de dados 
	        
	        connection = DriverManager.getConnection(url, username, password);
	    } catch (ClassNotFoundException e) {
	    	// N�o pode encontrar o driver para  Conectar
	    	connection = null;
	    	msgErro = "N�o foi poss�vel conectar ao BD. Driver n�o encontrado. \n" + e.getStackTrace();
	    	e.printStackTrace();
            } catch (SQLException e) { 
                // N�o pode efetuar a conexao com o banco
            	connection = null;
		    	msgErro = "N�o foi poss�vel efetuar a conex�o ao BD. \n" + e.getStackTrace();
		    	e.printStackTrace();
        }
        return connection; 
    }
	
	/*
	 * Desconecta do banco
	 * */
	public static boolean disconnect(Connection con) {
        boolean disConnected = false;
       
        try {
            Class.forName(driverName).newInstance();
            con = DriverManager.getConnection(url,username, password);
            con.close();
            disConnected = true;
        } catch( SQLException e ) {
            System.out.println(e.getMessage());
            disConnected = false;
        } catch ( ClassNotFoundException e ) {
            System.out.println(e.getMessage());
            disConnected = false;
        } catch ( InstantiationException e ) {
            System.out.println(e.getMessage());
            disConnected = false;
        } catch ( IllegalAccessException e ) {
            System.out.println(e.getMessage());
            disConnected = false;
        }

        return disConnected;
	}
	
	/*
	 * Executa uma consulta SQL, e retorna um ResultSet
	 * */
	public static ResultSet consultar( Connection con , String query) {
		ResultSet rs = null;
		Statement st;
		
		try{
			st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
			rs = st.executeQuery(query);

			return rs;
		}
		catch (SQLException e){
			e.printStackTrace();
		}
		return rs;
	}
	
	
	/*
	 * Insere/Apaga/Atualiza um novo registro no banco.
	 * */
	public static int execute( Connection con, String query ) {
		Statement st;
		int result = -1;

		try {
			st = con.createStatement();
			result = st.executeUpdate(query);
		} catch ( SQLException e ) {
			e.printStackTrace();
		}

		return result;
	}
	
}


