package com.example.jean.lpws;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


public class add extends Activity {

    private Handler handler;
    WifiManager mainWifiObj;
    ListView list;
    String wifis[];
    String action;

    // Informacoes do roteador/AP
    String[] BSSID; // basic service set identifier - nome da conexao
    String[] SSID; // service set identifier - identificador unico da conexao
    int[] RSSI; // received signal strength indicator - potencia do sinal (-87 a -32)

    static final String TAG = "GCMDemo";

    private TextView mDisplay,wDisplay;
    EditText edit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        handler = new Handler();
        mDisplay = (TextView) findViewById(R.id.textView);
        wDisplay = (TextView) findViewById(R.id.textView2);
        edit= (EditText) findViewById(R.id.editText);

        mainWifiObj = (WifiManager) getSystemService(Context.WIFI_SERVICE);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.add, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    protected void onResume() {
    super.onResume();
        handler.post(new Runnable() {
            public void run() {
                startWifiScan();
                wDisplay.setText("## Nome   Sinal   BSSID ##\n");
                for(int i=0;i<SSID.length;i++)
                wDisplay.append(SSID[i]+" "+RSSI[i]+" "+BSSID[i]+"\n");
            }

        });
    }
    public void adicionar(View v) {
        mDisplay.setText("Adicionando Localização");
        action="savel";
        sendPost();
        startWifiScan();
    }
    public void processar(View v) {
        mDisplay.setText("Processando Dados");
        action="commit";
        sendPost();
    }
    private void startWifiScan(){
        mainWifiObj.startScan();

        List<ScanResult> wifiScanList = mainWifiObj.getScanResults();
        wifis = new String[wifiScanList.size()];

        RSSI = new int[wifiScanList.size()];
        BSSID = new String[wifiScanList.size()];
        SSID = new String[wifiScanList.size()];

        for (int i = 0; i < wifiScanList.size(); i++) {
            wifis[i] = ((wifiScanList.get(i)).toString());
            BSSID[i] = (wifiScanList.get(i).BSSID);
            SSID[i] = (wifiScanList.get(i).SSID);
            RSSI[i] = wifiScanList.get(i).level;
            Log.i("WIFI LIST", wifis[i]);
        }
    }
    private void sendPost(){
        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {
                String result="";
                // Get user id from shared preferences
                final SharedPreferences prefs = getSharedPreferences(Main.class.getSimpleName(),
                        getApplicationContext().MODE_PRIVATE);
                // Create a new HttpClient and Post Header
                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost(Main.URL+"/lpws/receiver");

                try {
                    // Add your data
                    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(wifis.length+4);
                    nameValuePairs.add(new BasicNameValuePair("api_client_id", prefs.getString(Main.PROPERTY_REG_ID, "")));
                    nameValuePairs.add(new BasicNameValuePair("action", action));
                    nameValuePairs.add(new BasicNameValuePair("local", edit.getText().toString()));
                    nameValuePairs.add(new BasicNameValuePair("length",String.valueOf(wifis.length)));
                    for(int i=0;i<wifis.length;i++){
                        nameValuePairs.add(new BasicNameValuePair("WIFI_"+i, SSID[i]+"|"+BSSID[i]+"|"+String.valueOf(RSSI[i])));
                        Log.i(TAG,"WIFI_"+i+"|"+SSID[i]+"|"+BSSID[i]+"|"+String.valueOf(RSSI[i]));
                    }
                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    // Execute HTTP Post Request
                    HttpResponse response = httpclient.execute(httppost);
                    InputStream inputstream=response.getEntity().getContent();
                    BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputstream));
                    String line="";
                    while((line = bufferedReader.readLine()) != null) {
                        Log.i("SERVER",line);
                     if(line.charAt(0)=='#') {
                         line=line.substring(1);
                         result += line;
                     }
                    }
                    inputstream.close();
                } catch (ClientProtocolException e) {
                    // TODO Auto-generated catch block
                    result = "Error :" + e.getMessage();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    result  = "Error :" + e.getMessage();
                }
                return  result;
            }

            @Override
            protected void onPostExecute(String msg) {
                mDisplay.setText(msg);
            }
        }.execute(null, null, null);
    }
}
